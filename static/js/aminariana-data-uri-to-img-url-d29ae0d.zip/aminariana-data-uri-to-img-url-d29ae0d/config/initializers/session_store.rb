# Be sure to restart your server when you modify this file.

DataUriToImgUrl::Application.config.session_store :cookie_store, key: '_data-uri-to-img-url_session'
