The mocks in this directory contain images licensed as follows:

* First cat picture: CC0 Public Domain.
  [Source](https://pixabay.com/en/animal-cat-drawing-feline-kitten-1296305/):
  OpenClipartVectors
* Second cat picture: Creative Commons Attribution 3.0.
  [Source](http://xxspiritwolf2000xx.deviantart.com/art/Grumpy-cat-line-art-394007711):
  XXspiritwolf2000XX
